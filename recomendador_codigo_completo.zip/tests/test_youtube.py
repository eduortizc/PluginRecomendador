"""
test_youtube.py – Pruebas unitarias para la integración de YouTube Data API (E2).

Verifica el comportamiento de recuperación de candidatos, lectura de claves,
manejo de respuestas de YouTube, y gestión de errores (cuotas, red, respuestas vacías).
"""

import json
import os
import tempfile
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import MagicMock, patch

from recomendador.youtube import (
    ErrorYouTube,
    buscar_videos_youtube,
    obtener_clave_api,
)


class TestObtenerClaveApi(unittest.TestCase):

    def test_clave_desde_variable_entorno(self):
        with patch.dict(os.environ, {"YOUTUBE_API_KEY": "AIzaFakeEnvKey123"}):
            clave = obtener_clave_api()
            self.assertEqual(clave, "AIzaFakeEnvKey123")

    def test_clave_desde_archivo_env_formato_estandar(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            env_file = Path(tmpdir) / ".env"
            env_file.write_text("YOUTUBE_API_KEY=AIzaFileStandard456\n", encoding="utf-8")
            with patch.dict(os.environ, {}, clear=True):
                # Asegurar que no esté en el entorno
                if "YOUTUBE_API_KEY" in os.environ:
                    del os.environ["YOUTUBE_API_KEY"]
                clave = obtener_clave_api(ruta_env=env_file)
                self.assertEqual(clave, "AIzaFileStandard456")

    def test_clave_desde_archivo_env_formato_directo_con_comentarios(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            env_file = Path(tmpdir) / ".env"
            env_file.write_text("AIzaDirectKey789 // api key de prueba\n", encoding="utf-8")
            with patch.dict(os.environ, {}, clear=True):
                if "YOUTUBE_API_KEY" in os.environ:
                    del os.environ["YOUTUBE_API_KEY"]
                clave = obtener_clave_api(ruta_env=env_file)
                self.assertEqual(clave, "AIzaDirectKey789")

    def test_sin_clave_lanza_error_especifico(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            env_file = Path(tmpdir) / ".env"
            env_file.write_text("# archivo vacío\n", encoding="utf-8")
            with patch.dict(os.environ, {}, clear=True):
                if "YOUTUBE_API_KEY" in os.environ:
                    del os.environ["YOUTUBE_API_KEY"]
                with self.assertRaises(ErrorYouTube) as ctx:
                    obtener_clave_api(ruta_env=env_file)
                self.assertEqual(ctx.exception.codigo, "clave_no_encontrada")


class TestBuscarVideosYouTube(unittest.TestCase):

    def setUp(self):
        self.api_key = "AIzaTestKey_000000"

    @patch("urllib.request.urlopen")
    def test_busqueda_exitosa(self, mock_urlopen):
        mock_response = MagicMock()
        mock_payload = {
            "items": [
                {
                    "id": {"videoId": "vid_001"},
                    "snippet": {
                        "title": "Tutorial de &quot;Python&quot; desde Cero",
                        "description": "Aprende programaci&oacute;n y algoritmos bsicos.",
                        "channelTitle": "Canal Educativo",
                        "publishedAt": "2026-01-15T10:00:00Z",
                    },
                },
                {
                    "id": {"videoId": "vid_002"},
                    "snippet": {
                        "title": "Bases de Datos con Python",
                        "description": "SQL y conexiones prcticas.",
                        "channelTitle": "Dev Tutoriales",
                        "publishedAt": "2026-02-20T12:00:00Z",
                    },
                },
            ]
        }
        mock_response.read.return_value = json.dumps(mock_payload).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        resultados = buscar_videos_youtube("python", max_resultados=2, api_key=self.api_key)

        self.assertEqual(len(resultados), 2)
        primero = resultados[0]
        self.assertEqual(primero["id"], "vid_001")
        self.assertEqual(primero["titulo"], 'Tutorial de "Python" desde Cero')
        self.assertEqual(primero["canal"], "Canal Educativo")
        self.assertEqual(primero["origen"], "youtube")
        self.assertEqual(primero["url"], "https://www.youtube.com/watch?v=vid_001")

    @patch("urllib.request.urlopen")
    def test_busqueda_sin_resultados(self, mock_urlopen):
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({"items": []}).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        resultados = buscar_videos_youtube("tema_extremadamente_raro_sin_videos", api_key=self.api_key)
        self.assertEqual(resultados, [])

    def test_tema_vacio_lanza_value_error(self):
        with self.assertRaises(ValueError):
            buscar_videos_youtube("   ", api_key=self.api_key)

    @patch("urllib.request.urlopen")
    def test_error_cuota_excedida(self, mock_urlopen):
        err_body = json.dumps({
            "error": {
                "errors": [{"reason": "quotaExceeded", "message": "The request cannot be completed because you have exceeded your quota."}],
                "code": 403,
                "message": "Quota exceeded",
            }
        }).encode("utf-8")

        mock_http_error = urllib.error.HTTPError(
            url="https://www.googleapis.com/youtube/v3/search",
            code=403,
            msg="Forbidden",
            hdrs=None,
            fp=MagicMock(read=MagicMock(return_value=err_body)),
        )
        mock_urlopen.side_effect = mock_http_error

        with self.assertRaises(ErrorYouTube) as ctx:
            buscar_videos_youtube("python", api_key=self.api_key)
        self.assertEqual(ctx.exception.codigo, "cuota_excedida")

    @patch("urllib.request.urlopen")
    def test_error_peticion_invalida_400(self, mock_urlopen):
        err_body = json.dumps({
            "error": {
                "errors": [{"reason": "keyInvalid", "message": "Bad Request"}],
                "code": 400,
                "message": "API key not valid.",
            }
        }).encode("utf-8")

        mock_http_error = urllib.error.HTTPError(
            url="https://www.googleapis.com/youtube/v3/search",
            code=400,
            msg="Bad Request",
            hdrs=None,
            fp=MagicMock(read=MagicMock(return_value=err_body)),
        )
        mock_urlopen.side_effect = mock_http_error

        with self.assertRaises(ErrorYouTube) as ctx:
            buscar_videos_youtube("python", api_key=self.api_key)
        self.assertEqual(ctx.exception.codigo, "peticion_invalida")

    @patch("urllib.request.urlopen")
    def test_error_red_urlerror(self, mock_urlopen):
        mock_urlopen.side_effect = urllib.error.URLError("Network unreachable")

        with self.assertRaises(ErrorYouTube) as ctx:
            buscar_videos_youtube("python", api_key=self.api_key)
        self.assertEqual(ctx.exception.codigo, "error_red")

    @patch("urllib.request.urlopen")
    def test_error_tiempo_agotado(self, mock_urlopen):
        mock_urlopen.side_effect = TimeoutError()

        with self.assertRaises(ErrorYouTube) as ctx:
            buscar_videos_youtube("python", api_key=self.api_key)
        self.assertEqual(ctx.exception.codigo, "tiempo_agotado")

    @patch("urllib.request.urlopen")
    def test_error_servicio_503(self, mock_urlopen):
        err_body = b"Service Unavailable"
        mock_http_error = urllib.error.HTTPError(
            url="https://www.googleapis.com/youtube/v3/search",
            code=503,
            msg="Service Unavailable",
            hdrs=None,
            fp=MagicMock(read=MagicMock(return_value=err_body)),
        )
        mock_urlopen.side_effect = mock_http_error

        with self.assertRaises(ErrorYouTube) as ctx:
            buscar_videos_youtube("python", api_key=self.api_key)
        self.assertEqual(ctx.exception.codigo, "servicio_no_disponible")


if __name__ == "__main__":
    unittest.main()
